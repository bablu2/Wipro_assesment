package org.example;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        //Providing hardcoded path for the file
        try(FileInputStream fileInputStream = new FileInputStream("C:\\sharedFolder\\HashKeyGenatorFile\\TestFile.txt")){
            //Creates MessageDigest Instance for the SHA-256 Algorithm
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");

            //Setting the chunk size to read data in chunks
            byte[] buffer = new byte[8192];
            int bytesRead;

            //Reading and update the message bytes in chunks and updating digest
            while ((bytesRead = fileInputStream.read(buffer)) != -1){
                messageDigest.update(buffer,0, bytesRead);
            }

            byte[] hashBytes = messageDigest.digest();
            System.out.println(Arrays.toString(hashBytes));
            //Actual hashing is completed here for ease of reading we are converting it to hex
            StringBuilder hexString = new StringBuilder();
            for(byte b : hashBytes){
                String hex = Integer.toHexString(0xff & b);
                if(hex.length() == 1){
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            //we have converted each byte to a hexadecimal and converting it to string for ease of reading
            System.out.println(hexString);
        }

    }
}