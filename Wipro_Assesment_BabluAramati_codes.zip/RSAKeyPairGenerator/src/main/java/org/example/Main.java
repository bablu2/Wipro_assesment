package org.example;



import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;



public class Main {
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");

        keyPairGenerator.initialize(2048);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();

        try(FileOutputStream fileOutputStream = new FileOutputStream("C:\\sharedFolder\\RsaKeyPair\\public.key")){

            fileOutputStream.write(publicKey.getEncoded());
        }
        try(FileOutputStream fileOutputStream = new FileOutputStream("C:\\sharedFolder\\RsaKeyPair\\private.key")){
            fileOutputStream.write(privateKey.getEncoded());
        }
    }
}