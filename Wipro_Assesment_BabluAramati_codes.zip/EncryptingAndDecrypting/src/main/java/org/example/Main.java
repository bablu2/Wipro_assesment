package org.example;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class Main {
    public static void main(String[] args) throws Exception {
        encryptFile();
        decryptFile();
    }

    private static void decryptFile() throws Exception{
        byte[] bytes = Files.readAllBytes(Paths.get("C:\\sharedFolder\\RsaKeyPair\\private.key"));
        PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey pvt = kf.generatePrivate(ks);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, pvt);

        try (BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream("C:\\sharedFolder\\EncryptionAndDecryption\\Encrypted.txt"));
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream("C:\\sharedFolder\\EncryptionAndDecryption\\Decrypted.txt"))){

            byte[] buffer = new byte[8912];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1){
                byte[] decryptedChunk = cipher.doFinal(buffer,0, bytesRead);
                bufferedOutputStream.write(decryptedChunk);
            }
        }
    }

    private static void encryptFile() throws Exception {

        byte[] bytes = Files.readAllBytes(Paths.get("C:\\sharedFolder\\RsaKeyPair\\public.key"));
        X509EncodedKeySpec ks = new X509EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PublicKey pub = kf.generatePublic(ks);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, pub);

        try(BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream("C:\\sharedFolder\\EncryptionAndDecryption\\ReceivedFile.txt"));
            BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream("C:\\sharedFolder\\EncryptionAndDecryption\\Encrypted.txt"))){

            byte[] buffer = new byte[8912];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1){
                byte[] encryptedChunk = cipher.doFinal(buffer,0, bytesRead);
                outputStream.write(encryptedChunk);
            }
        }
    }
}